class TennisScorer
  
end